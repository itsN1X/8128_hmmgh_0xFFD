title: {{ title }}
layout: {{ layout }}
---
scaffold content