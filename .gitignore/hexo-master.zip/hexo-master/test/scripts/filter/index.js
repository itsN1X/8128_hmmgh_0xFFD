describe('Filter', function(){
  require('./excerpt');
  require('./external_link');
});