title: {{ title }}
layout: {{ layout }}
---
foo