describe('Utilities', function(){
  require('./file2');
  require('./html_tag');
  require('./permalink');
});