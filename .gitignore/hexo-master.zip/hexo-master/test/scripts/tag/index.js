describe('Tag', function(){
  require('./blockquote');
  require('./code');
  require('./gist');
  require('./iframe');
  require('./img');
  require('./include_code');
  require('./jsfiddle');
  require('./link');
  require('./pullquote');
  require('./raw');
  require('./vimeo');
  require('./youtube');
});