describe('Core', function(){
  require('./router');
});