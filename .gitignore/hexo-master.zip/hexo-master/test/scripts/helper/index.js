describe('Helper', function(){
  require('./date');
  require('./gravatar');
  require('./is');
  require('./number');
  require('./tag');
  require('./toc');
  require('./url');
});